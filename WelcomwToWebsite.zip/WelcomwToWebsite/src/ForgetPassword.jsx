import { Component } from "react";

class ForgetPassword extends Component
{
    render()
    {
        return(
           <p className="forgetPassword">Forget Password</p>
        )
    }
}

export default ForgetPassword