import { Component } from "react";

class LoginButton extends Component
{
    render()
    {
        return(
            <button className="LoginButton">
                LOGIN
            </button>
        )
    }
}

export default LoginButton