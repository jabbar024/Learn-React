import { Component } from "react";

class PassWord extends Component
{
    render()
    {
        return(
            <>
                 <i class="fa-solid fa-lock icon"></i>
                <input type="text" className="user"/>
            </>
           
        )
    }
}

export default PassWord