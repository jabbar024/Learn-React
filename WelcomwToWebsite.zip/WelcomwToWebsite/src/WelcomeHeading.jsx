import { Component } from "react";

class WelcomeHeading extends Component
{
    render()
    {
        return(
            <h1 className="welcomwHeading">
                Welcome to website
            </h1>
        )
    }
}

export default WelcomeHeading