import { Component } from "react";

class WelcomeDetails extends Component
{
    render()
    {
        return(
            <p className="welcomwDetails">
                Lorem ipsum, dolor sit amet consectetur adipisicing elit. Minima quod molestiae ratione repellat rem dolorem ad natus. Exercitationem ipsam laborum tempora similique accusantium dolore, assumenda sunt numquam pariatur molestiae odit?
            </p>
        )
    }
}

export default WelcomeDetails