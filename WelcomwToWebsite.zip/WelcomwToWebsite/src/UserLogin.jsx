import { Component } from "react";

class UserLogin extends Component
{
    render()
    {
        return(
            <h1 className="userLogin">
                USER LOGIN
            </h1>
        )
    }
}

export default UserLogin