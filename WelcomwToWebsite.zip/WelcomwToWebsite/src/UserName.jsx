import { Component } from "react";

class UserName extends Component
{
    render()
    {
        return(
            <>  
                <i class="fa-regular fa-user icon"></i>
                <input type="text" className="user"/>
            </>
          
        )
    }
}

export default UserName