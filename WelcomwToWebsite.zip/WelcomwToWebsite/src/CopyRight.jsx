import { Component } from "react";

class CopyWrite extends Component
{
    render()
    {
        return(
            <p className="freePic">Designed By <i class="fa-solid fa-robot"></i> Freepik</p>
        )
    }
}
export default CopyWrite